import { Router } from 'express';
import {addProduct} from '../controller/productController.js';
const router = Router();

  
  


router.post('/addproduct',addProduct)

export default router;