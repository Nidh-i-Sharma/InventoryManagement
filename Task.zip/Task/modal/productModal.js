import mongoose, { Schema } from 'mongoose'

const productSchema = new mongoose.Schema({
    productId:Number,
    quantity: Number,
    operation :["add","substract"]

});

var productModal = mongoose.model('product', productSchema)
export default productModal;