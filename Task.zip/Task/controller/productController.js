import productModal from '../modal/productModal'



export async function addProduct(req,res){
  try{
    const { operation } = req.params;
    const {productId, quantity} = req.body;
    
    if(!productId || !quantity){
      res.status(400).send({message:"send required data please"})
    }
    let product = await productModal.findOne({productId:productId});
    if(operation =='add'){
      let updatedQuantity= product.quantity + JSON.parse(quantity);
      let updatedDoc = await productModal.findOneAndUpdate({productId:productId},{quantity :updatedQuantity})
      return res.status(200).send({message:"product add successfully",data:updatedDoc})
    }
    if(operation =='substract'){
      let updatedQuantity= product.quantity - JSON.parse(quantity);
      let updatedDoc = await productModal.findOneAndUpdate({productId:productId},{quantity :updatedQuantity})
      return res.status(200).send({message:"product substract successfully",data:updatedDoc})
    }
  }catch(error){
    return res.status(500).send({message:"Internal Server Error!!"})
  }
}

//rmove product 